#!/bin/bash
# VoidAI v2 — Setup & Run Script for Oracle Linux 9
# Usage: bash setup_run.sh

set -e

echo "========================================"
echo "  VoidAI v2 — Oracle Linux 9 Setup"
echo "========================================"

# Install Python 3.11+ and ffmpeg if needed
if ! command -v python3.11 &>/dev/null && ! command -v python3.12 &>/dev/null; then
    echo "[*] Installing Python 3.11..."
    sudo dnf install -y python3.11 python3.11-pip 2>/dev/null || \
    sudo dnf install -y python3 python3-pip
fi

# edge-tts produces MP3; Telegram voice notes need OGG Opus.
# edge-tts 6.1.12 saves directly as OGG Opus when filename ends in .oga — no ffmpeg needed.

PYTHON=$(command -v python3.11 || command -v python3.12 || command -v python3)
echo "[*] Using Python: $PYTHON ($($PYTHON --version))"

# Create venv if not present
if [ ! -d "venv" ]; then
    echo "[*] Creating virtual environment..."
    $PYTHON -m venv venv
fi

source venv/bin/activate

echo "[*] Installing dependencies..."
pip install --upgrade pip -q
pip install -r requirements.txt -q

echo ""
echo "========================================"
echo "  Setup complete! Starting VoidAI v2..."
echo "========================================"
echo ""

python bot.py
