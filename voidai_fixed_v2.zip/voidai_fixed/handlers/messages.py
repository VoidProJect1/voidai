"""
VoidAI v2 — Message handler
Routes text and photo messages through the correct model pipeline.
FIX: await web_search (now async), build full Telegram file URL,
     pass caption keyword to reverse_image_search, fix voice reply.
"""

import os, logging
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ChatAction

from config import is_banned, BOT_TOKEN
from core.session import get_session, get_model, add_to_history, get_history, get_voice
from core.limiter import check_limit, record_usage
from core.ai_provider import ask_ai
from core.search import web_search, format_search_results
from core.image_analysis import download_image_b64, reverse_image_search, summarise_image_search
from core.voice import text_to_speech, clean_for_tts

logger = logging.getLogger(__name__)

# Telegram file download base URL
_TG_FILE_BASE = f"https://api.telegram.org/file/bot{BOT_TOKEN}/"


async def _send_voice_reply(update: Update, text: str, voice_name: str):
    """Send AI answer as a Telegram voice note with a clean text caption."""
    clean = clean_for_tts(text)
    audio_path = await text_to_speech(clean, voice_name)
    if audio_path:
        try:
            # Caption: first 900 chars of original text (Telegram limit 1024)
            caption = text[:900] if len(text) <= 900 else text[:897] + "…"
            with open(audio_path, "rb") as f:
                await update.message.reply_voice(voice=f, caption=f"🔊 {caption}")
        except Exception as e:
            logger.warning("Voice send error: %s", e)
            await update.message.reply_text(text)
        finally:
            try:
                os.unlink(audio_path)
            except Exception:
                pass
    else:
        # TTS failed — fall back to text
        await update.message.reply_text(text)


async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    uid  = user.id

    if is_banned(uid):
        await update.message.reply_text("🚫 You are banned from using VoidAI v2.")
        return

    model = get_model(uid)
    photo = update.message.photo

    # ── Image message ──────────────────────────────────────────────────────────
    if photo:
        if not check_limit(uid, model, "images"):
            await update.message.reply_text(
                "⏳ *Image analysis limit reached* for this hour.\n"
                "Try again later or ask an admin to raise your limit.",
                parse_mode="Markdown"
            )
            return
        record_usage(uid, "images")
        await update.message.chat.send_action(ChatAction.UPLOAD_PHOTO)

        # Get the highest-resolution photo
        tg_file    = await context.bot.get_file(photo[-1].file_id)
        # Build full download URL
        file_url   = _TG_FILE_BASE + tg_file.file_path
        image_b64  = await download_image_b64(file_url)

        if not image_b64:
            await update.message.reply_text("❌ Failed to download image. Please try again.")
            return

        caption = update.message.caption or "Describe this image in detail."

        extra_context = None
        if model == "pro":
            # Use caption as keyword for reverse search
            rev_results   = await reverse_image_search(caption, max_results=3)
            extra_context = summarise_image_search(rev_results)
            # Also web search the caption text
            web_res = await web_search(caption, max_results=3)
            raw     = format_search_results(web_res)
            if raw and raw != "No results found.":
                extra_context = ((extra_context + "\n" + raw) if extra_context else raw)[:800]

        await update.message.chat.send_action(ChatAction.TYPING)
        answer = await ask_ai(
            prompt=caption,
            history=get_history(uid),
            image_b64=image_b64,
            extra_context=extra_context,
        )

        add_to_history(uid, "user",      f"[Image] {caption}")
        add_to_history(uid, "assistant", answer)

        voice_on, voice_name = get_voice(uid)
        if voice_on:
            await _send_voice_reply(update, answer, voice_name)
        else:
            await update.message.reply_text(
                f"🖼️ *Image Analysis* — VoidAI v2\n\n{answer}",
                parse_mode="Markdown"
            )
        return

    # ── Text message ───────────────────────────────────────────────────────────
    text = update.message.text or ""
    if not text:
        return

    if not check_limit(uid, model, "messages"):
        await update.message.reply_text(
            "⏳ *Message limit reached* for this hour.\n"
            "Upgrade your plan or wait for the limit to reset.",
            parse_mode="Markdown"
        )
        return
    record_usage(uid, "messages")
    await update.message.chat.send_action(ChatAction.TYPING)

    extra_context = None

    # Pro mode — auto web search
    if model == "pro":
        if check_limit(uid, model, "searches"):
            record_usage(uid, "searches")
            results       = await web_search(text, max_results=4)
            raw           = format_search_results(results)
            if raw and raw != "No results found.":
                extra_context = raw[:800]

    answer = await ask_ai(
        prompt=text,
        history=get_history(uid),
        extra_context=extra_context,
    )

    add_to_history(uid, "user",      text)
    add_to_history(uid, "assistant", answer)

    voice_on, voice_name = get_voice(uid)
    if voice_on:
        await _send_voice_reply(update, answer, voice_name)
    else:
        badge = {"lite": "⚡ Void Lite", "flash": "🔥 Void Flash", "pro": "🚀 Void Pro"}[model]
        await update.message.reply_text(
            f"{badge} · VoidAI v2\n\n{answer}",
            parse_mode="Markdown"
        )
