"""
VoidAI v2 — Voice reply using Microsoft Edge TTS
FIX: save as .oga (OGG Opus) so Telegram accepts it as voice note.
     clean_for_tts now strips emojis and markdown properly.
"""

import asyncio, os, logging, tempfile, re
import edge_tts

logger = logging.getLogger(__name__)

INDIAN_VOICES = {
    "🇮🇳 Hindi - Swara (Female)":    "hi-IN-SwaraNeural",
    "🇮🇳 Hindi - Madhur (Male)":     "hi-IN-MadhurNeural",
    "🇮🇳 English - Neerja (Female)": "en-IN-NeerjaNeural",
    "🇮🇳 English - Prabhat (Male)":  "en-IN-PrabhatNeural",
    "🇮🇳 Telugu - Shruti (Female)":  "te-IN-ShrutiNeural",
    "🇮🇳 Telugu - Mohan (Male)":     "te-IN-MohanNeural",
    "🇮🇳 Tamil - Pallavi (Female)":  "ta-IN-PallaviNeural",
    "🇮🇳 Tamil - Valluvar (Male)":   "ta-IN-ValluvarNeural",
    "🇮🇳 Kannada - Sapna (Female)":  "kn-IN-SapnaNeural",
    "🇮🇳 Kannada - Gagan (Male)":    "kn-IN-GaganNeural",
}

# Emoji unicode ranges
_EMOJI_RE = re.compile(
    "["
    u"\U0001F600-\U0001F64F"
    u"\U0001F300-\U0001F5FF"
    u"\U0001F680-\U0001F6FF"
    u"\U0001F1E0-\U0001F1FF"
    u"\U00002702-\U000027B0"
    u"\U000024C2-\U0001F251"
    u"\U0001f926-\U0001f937"
    u"\U00010000-\U0010ffff"
    u"\u2640-\u2642"
    u"\u2600-\u2B55"
    u"\u200d"
    u"\u23cf"
    u"\u23e9"
    u"\u231a"
    u"\ufe0f"
    u"\u3030"
    "]+",
    flags=re.UNICODE,
)


def clean_for_tts(text: str) -> str:
    """Remove markdown, emojis, URLs for cleaner TTS audio."""
    # Remove markdown
    text = re.sub(r"\*+|_+|`+|#+|~+", "", text)
    # Remove URLs
    text = re.sub(r"https?://\S+", "", text)
    # Remove inline links [text](url)
    text = re.sub(r"\[([^\]]+)\]\([^\)]+\)", r"\1", text)
    # Remove emojis
    text = _EMOJI_RE.sub("", text)
    # Collapse whitespace
    text = re.sub(r"\s+", " ", text).strip()
    return text[:1200]   # cap to ~60 seconds of speech


async def text_to_speech(text: str, voice: str = "hi-IN-SwaraNeural") -> str | None:
    """Convert text to OGA voice file path (Telegram voice note format)."""
    if not text or not text.strip():
        return None
    try:
        # Use .oga extension — Telegram requires OGG Opus for voice notes
        tmp = tempfile.NamedTemporaryFile(suffix=".oga", delete=False)
        tmp.close()
        communicate = edge_tts.Communicate(text, voice)
        await communicate.save(tmp.name)
        # Verify file is non-empty
        if os.path.getsize(tmp.name) < 100:
            os.unlink(tmp.name)
            logger.warning("TTS produced empty/tiny file for voice=%s", voice)
            return None
        return tmp.name
    except Exception as e:
        logger.warning("TTS error voice=%s: %s", voice, e)
        return None
