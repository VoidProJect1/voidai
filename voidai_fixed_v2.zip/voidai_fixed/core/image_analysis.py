"""
VoidAI v2 — Image analysis
Downloads Telegram photo → base64 for Gemini vision.
Pro mode: DuckDuckGo text search using AI-generated description as reverse search.
FIX: reverse_image_search is now async-safe via asyncio.to_thread.
     download_image_b64 accepts full URL directly (caller must build it).
"""

import asyncio, base64, httpx, logging

logger = logging.getLogger(__name__)


async def download_image_b64(file_url: str) -> str | None:
    """Download a Telegram file URL and return base64-encoded bytes."""
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.get(file_url)
        r.raise_for_status()
        return base64.b64encode(r.content).decode()
    except Exception as e:
        logger.warning("Image download error (%s): %s", file_url[:60], e)
        return None


def _ddgs_image_sync(keyword: str, max_results: int) -> list:
    """Blocking DDG image/text search — run via asyncio.to_thread."""
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            # Use text search for richer context
            results = list(ddgs.text(keyword, max_results=max_results))
        return results
    except Exception as e:
        logger.warning("Reverse image search error: %s", e)
        return []


async def reverse_image_search(keyword: str, max_results: int = 3) -> list:
    """
    Async reverse-search using a descriptive keyword derived from the image caption.
    True pixel-level reverse search is not possible without a paid API,
    so we search the caption/context as the best available proxy.
    """
    if not keyword or len(keyword) < 3:
        return []
    return await asyncio.to_thread(_ddgs_image_sync, keyword, max_results)


def summarise_image_search(results: list) -> str:
    if not results:
        return ""
    parts = []
    for r in results:
        title = r.get("title", "")
        body  = r.get("body", "")[:150]
        if title:
            parts.append(f"{title}: {body}")
    return "Related web context: " + " | ".join(parts)[:500]
