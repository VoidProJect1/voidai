"""
VoidAI v2 — Admin handler
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from config import get_config, save_config, is_admin, get_admin_ids, BOOTSTRAP_ADMIN_ID
from core.limiter import _usage, _window

logger = logging.getLogger(__name__)


def _require_admin(uid: int) -> bool:
    return is_admin(uid)


# ── /admin ────────────────────────────────────────────────────────────────────
async def admin_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not _require_admin(uid):
        await update.message.reply_text("🚫 *Admin access required.*", parse_mode="Markdown")
        return

    cfg = get_config()
    gemini_count  = len(cfg.get("gemini_keys", []))
    grok_count    = len(cfg.get("grok_keys", []))
    mistral_count = len(cfg.get("mistral_keys", []))
    banned_count  = len(cfg.get("banned_users", []))
    admin_count   = len(cfg.get("admin_ids", []))

    buttons = [
        [InlineKeyboardButton("🔑 Manage API Keys", callback_data="admin:keys")],
        [InlineKeyboardButton("📊 Usage Stats",      callback_data="admin:stats")],
        [InlineKeyboardButton("🚫 Banned Users",     callback_data="admin:bans")],
        [InlineKeyboardButton("⚙️ Set Limits",       callback_data="admin:limits")],
    ]

    await update.message.reply_text(
        "🛡️ *VoidAI v2 — Admin Panel*\n\n"
        f"👑 Admin users: `{admin_count}`\n"
        f"🔑 Gemini Keys: `{gemini_count}`\n"
        f"🔑 Grok Keys: `{grok_count}`\n"
        f"🔑 Mistral Keys: `{mistral_count}`\n"
        f"🚫 Banned users: `{banned_count}`\n\n"
        f"*Commands:*\n"
        f"`/addadmin <user_id>` — Add admin\n"
        f"`/ban <user_id>` — Ban/unban user\n"
        f"`/limit <multiplier>` — Set global limit\n"
        f"`/limit <user_id> <multiplier>` — Per-user limit\n"
        f"`/stats` — Usage overview\n"
        f"`/addkey gemini <key>` — Add Gemini key\n"
        f"`/addkey grok <key>` — Add Grok key\n"
        f"`/addkey mistral <key>` — Add Mistral key\n",
        reply_markup=InlineKeyboardMarkup(buttons),
        parse_mode="Markdown"
    )


# ── /addadmin ─────────────────────────────────────────────────────────────────
async def addadmin_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not _require_admin(uid):
        await update.message.reply_text("🚫 *Admin access required.*", parse_mode="Markdown")
        return

    if not context.args:
        await update.message.reply_text(
            "Usage: `/addadmin <user_id>`",
            parse_mode="Markdown"
        )
        return

    try:
        target_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ Invalid user ID.", parse_mode="Markdown")
        return

    cfg = get_config()
    if target_id not in cfg["admin_ids"]:
        cfg["admin_ids"].append(target_id)
        save_config(cfg)
        await update.message.reply_text(
            f"✅ *User `{target_id}` is now an admin!*",
            parse_mode="Markdown"
        )
        try:
            await context.bot.send_message(
                chat_id=target_id,
                text="🛡️ *You have been granted admin access to VoidAI v2!*\n\nUse /admin to open the panel.",
                parse_mode="Markdown"
            )
        except Exception:
            pass
    else:
        cfg["admin_ids"].remove(target_id)
        save_config(cfg)
        await update.message.reply_text(
            f"♻️ *User `{target_id}` admin access removed.*",
            parse_mode="Markdown"
        )


# ── /ban ──────────────────────────────────────────────────────────────────────
async def ban_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not _require_admin(uid):
        return

    target_id = None
    if update.message.reply_to_message:
        target_id = update.message.reply_to_message.from_user.id
    elif context.args:
        try:
            target_id = int(context.args[0])
        except ValueError:
            pass

    if not target_id:
        await update.message.reply_text(
            "Usage: `/ban <user_id>` or reply to a message",
            parse_mode="Markdown"
        )
        return

    cfg = get_config()
    if target_id not in cfg["banned_users"]:
        cfg["banned_users"].append(target_id)
        save_config(cfg)
        await update.message.reply_text(
            f"✅ *User `{target_id}` has been banned.*",
            parse_mode="Markdown"
        )
    else:
        cfg["banned_users"].remove(target_id)
        save_config(cfg)
        await update.message.reply_text(
            f"♻️ *User `{target_id}` has been unbanned.*",
            parse_mode="Markdown"
        )


# ── /limit ────────────────────────────────────────────────────────────────────
async def limit_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not _require_admin(uid):
        return

    args = context.args
    cfg = get_config()

    if len(args) == 2:
        try:
            target_id  = int(args[0])
            multiplier = float(args[1])
        except ValueError:
            await update.message.reply_text("Usage: `/limit <user_id> <multiplier>`", parse_mode="Markdown")
            return

        cfg["user_limit_multipliers"][str(target_id)] = multiplier
        save_config(cfg)

        try:
            await context.bot.send_message(
                chat_id=target_id,
                text=(
                    f"🎉 *Limit Update from VoidAI v2 Admin!*\n\n"
                    f"⚡ Your usage limit has been set to *{multiplier}x*!\n"
                    f"{'🚀 Enjoy the extra power!' if multiplier > 1 else '⚠️ Your usage has been restricted.'}\n\n"
                    f"— VoidAI v2 Team 🌌"
                ),
                parse_mode="Markdown"
            )
        except Exception:
            pass

        await update.message.reply_text(
            f"✅ *User `{target_id}` limit set to {multiplier}x*",
            parse_mode="Markdown"
        )

    elif len(args) == 1:
        try:
            multiplier = float(args[0])
        except ValueError:
            await update.message.reply_text("Usage: `/limit <multiplier>`", parse_mode="Markdown")
            return

        cfg["user_limit_multipliers"]["global"] = multiplier
        save_config(cfg)
        await update.message.reply_text(
            f"✅ *Global limit multiplier set to {multiplier}x*",
            parse_mode="Markdown"
        )
    else:
        await update.message.reply_text(
            "Usage:\n"
            "`/limit <multiplier>` — global\n"
            "`/limit <user_id> <multiplier>` — specific user",
            parse_mode="Markdown"
        )


# ── /stats ────────────────────────────────────────────────────────────────────
async def stats_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not _require_admin(uid):
        return

    total_users = len(_usage)
    total_msgs = sum(
        len([t for t in data.get("messages", []) if t > _window()])
        for data in _usage.values()
    )
    total_searches = sum(
        len([t for t in data.get("searches", []) if t > _window()])
        for data in _usage.values()
    )
    total_images = sum(
        len([t for t in data.get("images", []) if t > _window()])
        for data in _usage.values()
    )

    cfg = get_config()
    banned = len(cfg.get("banned_users", []))

    await update.message.reply_text(
        "📊 *VoidAI v2 — Live Stats (last hour)*\n\n"
        f"👥 Active users: `{total_users}`\n"
        f"💬 Messages processed: `{total_msgs}`\n"
        f"🔍 Web searches: `{total_searches}`\n"
        f"🖼️ Image analyses: `{total_images}`\n"
        f"🚫 Banned users: `{banned}`\n\n"
        f"🔑 Gemini Keys: `{len(cfg.get('gemini_keys', []))}`\n"
        f"🔑 Grok Keys: `{len(cfg.get('grok_keys', []))}`\n"
        f"🔑 Mistral Keys: `{len(cfg.get('mistral_keys', []))}`\n\n"
        f"— VoidAI v2 Admin Panel 🛡️",
        parse_mode="Markdown"
    )


# ── /addkey ───────────────────────────────────────────────────────────────────
async def addkey_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not _require_admin(uid):
        await update.message.reply_text("🚫 *Admin access required.*", parse_mode="Markdown")
        return

    args = context.args
    if len(args) < 2:
        await update.message.reply_text(
            "Usage: `/addkey <gemini|grok|mistral> <API_KEY>`",
            parse_mode="Markdown"
        )
        return

    provider = args[0].lower()
    key      = args[1].strip()
    cfg      = get_config()

    key_map = {
        "gemini":  "gemini_keys",
        "grok":    "grok_keys",
        "mistral": "mistral_keys",
    }

    if provider not in key_map:
        await update.message.reply_text("❌ Unknown provider. Use: gemini, grok, or mistral")
        return

    field = key_map[provider]
    if key not in cfg[field]:
        cfg[field].append(key)
        save_config(cfg)
        await update.message.reply_text(
            f"✅ *{provider.capitalize()} API key added!*\n"
            f"Total {provider} keys: `{len(cfg[field])}`",
            parse_mode="Markdown"
        )
    else:
        await update.message.reply_text("⚠️ Key already exists.")

    # Delete message to keep key secret
    try:
        await update.message.delete()
    except Exception:
        pass


# ── Callback from admin buttons ───────────────────────────────────────────────
async def handle_admin_callback(update, context, data: str):
    query = update.callback_query
    cfg   = get_config()
    action = data.split(":")[1]

    if action == "stats":
        await query.edit_message_text(
            "📊 Use /stats for live stats.",
            parse_mode="Markdown"
        )
    elif action == "keys":
        await query.edit_message_text(
            "🔑 *Manage API Keys*\n\n"
            f"Gemini: `{len(cfg.get('gemini_keys', []))}` keys\n"
            f"Grok: `{len(cfg.get('grok_keys', []))}` keys\n"
            f"Mistral: `{len(cfg.get('mistral_keys', []))}` keys\n\n"
            "Use `/addkey gemini <key>` to add a key.",
            parse_mode="Markdown"
        )
    elif action == "bans":
        bans = cfg.get("banned_users", [])
        text = "🚫 *Banned Users*\n\n"
        text += "\n".join([f"• `{b}`" for b in bans]) if bans else "_No banned users_"
        await query.edit_message_text(text, parse_mode="Markdown")
    elif action == "limits":
        limits = cfg.get("limits", {})
        await query.edit_message_text(
            "⚙️ *Current Limits (per hour)*\n\n"
            f"⚡ *Lite* — msgs: `{limits['lite']['messages']}`, "
            f"imgs: `{limits['lite']['images']}`, "
            f"searches: `{limits['lite']['searches']}`\n\n"
            f"🔥 *Flash* — msgs: `{limits['flash']['messages']}`, "
            f"imgs: `{limits['flash']['images']}`, "
            f"searches: `{limits['flash']['searches']}`\n\n"
            f"🚀 *Pro* — msgs: `{limits['pro']['messages']}`, "
            f"imgs: `{limits['pro']['images']}`, "
            f"searches: `{limits['pro']['searches']}`\n\n"
            "Use `/limit <multiplier>` to adjust globally.",
            parse_mode="Markdown"
        )
