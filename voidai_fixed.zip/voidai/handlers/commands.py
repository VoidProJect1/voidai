"""
VoidAI v2 — Command handlers
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ChatAction

from config import is_banned
from core.session import (
    get_model, set_model, reset_session, get_voice, set_voice, get_history, add_to_history
)
from core.limiter import check_limit, record_usage
from core.ai_provider import ask_ai
from core.search import web_search, format_search_for_user
from core.voice import INDIAN_VOICES, text_to_speech, clean_for_tts

logger = logging.getLogger(__name__)

MODEL_LABELS = {
    "lite":  ("⚡ Void Lite",  "Basic answering — fast & efficient"),
    "flash": ("🔥 Void Flash", "Powered by Gemini 2.0 Flash — smarter"),
    "pro":   ("🚀 Void Pro",   "Web-augmented answers — most powerful"),
}


# ── /start ────────────────────────────────────────────────────────────────────
async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid  = update.effective_user.id
    name = update.effective_user.first_name
    model = get_model(uid)
    badge = MODEL_LABELS[model][0]

    await update.message.reply_text(
        f"👋 *Hey {name}!* Welcome to *VoidAI v2* 🌌\n\n"
        f"Currently in: {badge} mode\n\n"
        f"📌 *Quick commands:*\n"
        f"• /switch — Change AI model\n"
        f"• /web <query> — Search the web\n"
        f"• /voicereply — Toggle voice replies\n"
        f"• /new — Start fresh chat\n"
        f"• /help — All features\n\n"
        f"_Just send a message and I'll respond!_ 🚀",
        parse_mode="Markdown"
    )


# ── /help ─────────────────────────────────────────────────────────────────────
async def help_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📖 *VoidAI v2 — Command Guide*\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "⚡ *Models*\n"
        "• *Void Lite* — Fast Q&A, no web\n"
        "• *Void Flash* — Gemini 2.0 Flash\n"
        "• *Void Pro* — Web-enriched answers\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "💬 *Commands*\n"
        "/start — Welcome screen\n"
        "/switch — Switch AI model\n"
        "/new — Clear chat history\n"
        "/web <query> — Web search (no AI)\n"
        "/summarize — Summarize replied msg\n"
        "/voicereply — Toggle voice mode\n"
        "/help — This menu\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "🖼️ *Images*\n"
        "Send any image → AI analyzes it\n"
        "Pro mode: also searches the web\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "🔊 *Voice Mode*\n"
        "Replies sent as audio + text caption\n"
        "Choose from Indian voices\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "_VoidAI v2 · Always learning_ 🌌",
        parse_mode="Markdown"
    )


# ── /new ──────────────────────────────────────────────────────────────────────
async def new_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    reset_session(uid)
    await update.message.reply_text(
        "🔄 *Chat cleared!* Fresh start.\n"
        "_VoidAI v2 has no memory of previous messages._ 🧠",
        parse_mode="Markdown"
    )


# ── /switch ───────────────────────────────────────────────────────────────────
async def switch_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    current = get_model(uid)

    buttons = []
    for key, (label, desc) in MODEL_LABELS.items():
        tick = " ✅" if key == current else ""
        buttons.append([InlineKeyboardButton(f"{label}{tick}", callback_data=f"switch:{key}")])

    await update.message.reply_text(
        "🔀 *Select AI Model*\n\n"
        "⚡ *Void Lite* — Basic answering\n"
        "🔥 *Void Flash* — Gemini 2.0 powered\n"
        "🚀 *Void Pro* — Web-augmented AI\n",
        reply_markup=InlineKeyboardMarkup(buttons),
        parse_mode="Markdown"
    )


# ── /summarize ────────────────────────────────────────────────────────────────
async def summarize_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid  = update.effective_user.id
    replied = update.message.reply_to_message

    if not replied or not replied.text:
        await update.message.reply_text(
            "↩️ *Reply to a message* and then use /summarize to summarize it.",
            parse_mode="Markdown"
        )
        return

    if is_banned(uid):
        return

    await update.message.chat.send_action(ChatAction.TYPING)
    model = get_model(uid)

    summary = await ask_ai(
        prompt=f"Summarize this in 2-3 lines only:\n\n{replied.text}",
        history=[],
    )

    await update.message.reply_text(
        f"📝 *Summary* — VoidAI v2\n\n{summary}",
        parse_mode="Markdown"
    )


# ── /web ──────────────────────────────────────────────────────────────────────
async def web_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid   = update.effective_user.id
    model = get_model(uid)
    query = " ".join(context.args) if context.args else ""

    if not query:
        await update.message.reply_text(
            "🔍 Usage: `/web your search query`",
            parse_mode="Markdown"
        )
        return

    if is_banned(uid):
        return

    if not check_limit(uid, model, "searches"):
        await update.message.reply_text(
            "⏳ *Search limit reached* for this hour.\n"
            "Limit resets every 60 minutes.",
            parse_mode="Markdown"
        )
        return

    record_usage(uid, "searches")
    await update.message.chat.send_action(ChatAction.TYPING)

    results = web_search(query, max_results=5)
    text    = format_search_for_user(query, results)

    await update.message.reply_text(text, parse_mode="Markdown", disable_web_page_preview=False)


# ── /voicereply ───────────────────────────────────────────────────────────────
async def voicereply_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    voice_on, current_voice = get_voice(uid)

    if context.args and context.args[0].lower() == "off":
        set_voice(uid, False)
        await update.message.reply_text(
            "🔇 *Voice replies disabled.*\n"
            "I'll respond with text only now.",
            parse_mode="Markdown"
        )
        return

    # Ask which voice
    buttons = []
    for display, code in INDIAN_VOICES.items():
        tick = " ✅" if code == current_voice else ""
        buttons.append([InlineKeyboardButton(f"{display}{tick}", callback_data=f"voice:{code}")])

    state = "🟢 ON" if voice_on else "🔴 OFF"
    await update.message.reply_text(
        f"🔊 *Voice Reply — {state}*\n\n"
        f"Choose your preferred Indian voice:\n"
        f"_(Use /voicereply off to disable)_",
        reply_markup=InlineKeyboardMarkup(buttons),
        parse_mode="Markdown"
    )
