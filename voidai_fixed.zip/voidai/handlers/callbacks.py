"""
VoidAI v2 — Callback query handler (inline buttons)
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from core.session import set_model, set_voice, get_model


MODEL_LABELS = {
    "lite":  "⚡ Void Lite",
    "flash": "🔥 Void Flash",
    "pro":   "🚀 Void Pro",
}

VOICE_DISPLAY = {
    "hi-IN-SwaraNeural":   "🇮🇳 Hindi - Swara (Female)",
    "hi-IN-MadhurNeural":  "🇮🇳 Hindi - Madhur (Male)",
    "en-IN-NeerjaNeural":  "🇮🇳 English - Neerja (Female)",
    "en-IN-PrabhatNeural": "🇮🇳 English - Prabhat (Male)",
    "te-IN-ShrutiNeural":  "🇮🇳 Telugu - Shruti (Female)",
    "te-IN-MohanNeural":   "🇮🇳 Telugu - Mohan (Male)",
    "ta-IN-PallaviNeural": "🇮🇳 Tamil - Pallavi (Female)",
    "ta-IN-ValluvarNeural":"🇮🇳 Tamil - Valluvar (Male)",
    "kn-IN-SapnaNeural":   "🇮🇳 Kannada - Sapna (Female)",
    "kn-IN-GaganNeural":   "🇮🇳 Kannada - Gagan (Male)",
}


async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    uid  = query.from_user.id
    data = query.data

    # ── Model switch ──────────────────────────────────────────────────────────
    if data.startswith("switch:"):
        model = data.split(":")[1]
        set_model(uid, model)
        label = MODEL_LABELS.get(model, model)
        await query.edit_message_text(
            f"✅ *Switched to {label}!*\n\n"
            f"_Your next message will use this model._\n\n"
            f"— VoidAI v2 🌌",
            parse_mode="Markdown"
        )

    # ── Voice selection ───────────────────────────────────────────────────────
    elif data.startswith("voice:"):
        voice_code = data.split(":", 1)[1]
        set_voice(uid, True, voice_code)
        display = VOICE_DISPLAY.get(voice_code, voice_code)
        await query.edit_message_text(
            f"🔊 *Voice replies enabled!*\n\n"
            f"Selected: *{display}*\n\n"
            f"✨ I'll send audio replies from now on.\n"
            f"Use /voicereply off to disable.\n\n"
            f"— VoidAI v2 🌌",
            parse_mode="Markdown"
        )

    # ── Admin callbacks ───────────────────────────────────────────────────────
    elif data.startswith("admin:"):
        from handlers.admin import handle_admin_callback
        await handle_admin_callback(update, context, data)
