"""
VoidAI v2 — Message handler
Routes text and photo messages through the correct model pipeline.
"""

import os, logging
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ChatAction

from config import is_banned
from core.session import get_session, get_model, add_to_history, get_history, get_voice
from core.limiter import check_limit, record_usage
from core.ai_provider import ask_ai
from core.search import web_search, format_search_results
from core.image_analysis import download_image_b64, reverse_image_search, summarise_image_search
from core.voice import text_to_speech, clean_for_tts

logger = logging.getLogger(__name__)


async def _send_voice_reply(update: Update, text: str, voice_name: str):
    audio_path = await text_to_speech(clean_for_tts(text), voice_name)
    if audio_path:
        with open(audio_path, "rb") as f:
            await update.message.reply_voice(
                voice=f,
                caption=f"🔊 *Voice Reply* — VoidAI v2\n\n_{text[:200]}_",
                parse_mode="Markdown",
            )
        os.unlink(audio_path)
    else:
        await update.message.reply_text(text, parse_mode="Markdown")


async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    uid  = user.id

    if is_banned(uid):
        await update.message.reply_text("🚫 You are banned from using VoidAI v2.")
        return

    model = get_model(uid)
    photo = update.message.photo

    # ── Image message ──────────────────────────────────────────────────────────
    if photo:
        if not check_limit(uid, model, "images"):
            await update.message.reply_text(
                "⏳ *Image analysis limit reached* for this hour.\n"
                "Try again later or ask an admin to raise your limit.",
                parse_mode="Markdown"
            )
            return
        record_usage(uid, "images")
        await update.message.chat.send_action(ChatAction.UPLOAD_PHOTO)

        # Download the photo
        file = await context.bot.get_file(photo[-1].file_id)
        image_b64 = await download_image_b64(file.file_path)
        caption   = update.message.caption or "Describe this image in detail."

        extra_context = None
        if model == "pro":
            # Reverse search + web enrichment
            results = reverse_image_search(file.file_path)
            extra_context = summarise_image_search(results)
            # Also web search the caption
            if caption and len(caption) > 5:
                web_res = web_search(caption, max_results=3)
                raw = format_search_results(web_res)
                extra_context = (extra_context + "\n" + raw)[:800]

        await update.message.chat.send_action(ChatAction.TYPING)
        answer = await ask_ai(
            prompt=caption,
            history=get_history(uid),
            image_b64=image_b64,
            extra_context=extra_context,
        )

        add_to_history(uid, "user",      f"[Image] {caption}")
        add_to_history(uid, "assistant", answer)

        voice_on, voice_name = get_voice(uid)
        if voice_on:
            await _send_voice_reply(update, answer, voice_name)
        else:
            await update.message.reply_text(
                f"🖼️ *Image Analysis* — VoidAI v2\n\n{answer}",
                parse_mode="Markdown"
            )
        return

    # ── Text message ───────────────────────────────────────────────────────────
    text = update.message.text or ""
    if not text:
        return

    if not check_limit(uid, model, "messages"):
        await update.message.reply_text(
            "⏳ *Message limit reached* for this hour.\n"
            "Upgrade your plan or wait for the limit to reset.",
            parse_mode="Markdown"
        )
        return
    record_usage(uid, "messages")
    await update.message.chat.send_action(ChatAction.TYPING)

    extra_context = None

    # Pro mode — auto-web-search for every message
    if model == "pro":
        if check_limit(uid, model, "searches"):
            record_usage(uid, "searches")
            results = web_search(text, max_results=4)
            raw = format_search_results(results)
            extra_context = raw[:800]

    answer = await ask_ai(
        prompt=text,
        history=get_history(uid),
        extra_context=extra_context,
    )

    add_to_history(uid, "user",      text)
    add_to_history(uid, "assistant", answer)

    voice_on, voice_name = get_voice(uid)
    if voice_on:
        await _send_voice_reply(update, answer, voice_name)
    else:
        badge = {"lite": "⚡ Void Lite", "flash": "🔥 Void Flash", "pro": "🚀 Void Pro"}[model]
        await update.message.reply_text(
            f"{badge} · VoidAI v2\n\n{answer}",
            parse_mode="Markdown"
        )
