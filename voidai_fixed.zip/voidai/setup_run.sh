#!/bin/bash
# VoidAI v2 — Setup & Run Script for Oracle Linux 9
# Usage: bash setup_run.sh

set -e

echo "========================================"
echo "  VoidAI v2 — Oracle Linux 9 Setup"
echo "========================================"

# Install Python 3.11+ if needed
if ! command -v python3 &>/dev/null; then
    echo "[*] Installing Python 3..."
    sudo dnf install -y python3 python3-pip
fi

PYTHON=$(command -v python3.11 || command -v python3.12 || command -v python3)
echo "[*] Using Python: $PYTHON ($($PYTHON --version))"

# Create venv if not present
if [ ! -d "venv" ]; then
    echo "[*] Creating virtual environment..."
    $PYTHON -m venv venv
fi

source venv/bin/activate

echo "[*] Installing dependencies..."
pip install --upgrade pip -q
pip install -r requirements.txt -q

echo ""
echo "========================================"
echo "  Setup complete! Starting bot..."
echo "========================================"
echo ""

python bot.py
