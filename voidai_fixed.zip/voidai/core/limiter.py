"""
VoidAI v2 — Rate limiter
Tracks hourly usage per user per action type.
"""

import time
from config import get_config

# {user_id: {action: [timestamps]}}
_usage: dict[int, dict[str, list]] = {}


def _window() -> float:
    return time.time() - 3600   # 1-hour rolling window


def _get_limit(user_id: int, model: str, action: str) -> int:
    cfg = get_config()
    base = cfg["limits"].get(model, {}).get(action, 50)
    multiplier = cfg["user_limit_multipliers"].get(str(user_id), 1)
    return int(base * multiplier)


def check_limit(user_id: int, model: str, action: str = "messages") -> bool:
    """Return True if allowed, False if over limit."""
    if user_id not in _usage:
        _usage[user_id] = {}
    stamps = _usage[user_id].get(action, [])
    # prune old
    stamps = [t for t in stamps if t > _window()]
    _usage[user_id][action] = stamps

    limit = _get_limit(user_id, model, action)
    return len(stamps) < limit


def record_usage(user_id: int, action: str = "messages"):
    if user_id not in _usage:
        _usage[user_id] = {}
    _usage[user_id].setdefault(action, []).append(time.time())


def get_usage_stats(user_id: int, model: str) -> dict:
    cfg = get_config()
    actions = ["messages", "images", "searches"]
    result = {}
    for a in actions:
        stamps = _usage.get(user_id, {}).get(a, [])
        used = len([t for t in stamps if t > _window()])
        limit = _get_limit(user_id, model, a)
        result[a] = {"used": used, "limit": limit}
    return result
