"""
VoidAI v2 — AI Provider
Multi-key, multi-model rotation:
  Gemini Flash → Gemini 2.0 Flash (alt keys) → Gemini 1.5 Flash
  → Grok keys → Mistral keys
"""

import httpx, json, logging, asyncio
from config import get_config

logger = logging.getLogger(__name__)

# ── Model cascade ─────────────────────────────────────────────────────────────
GEMINI_MODELS = [
    "gemini-2.0-flash",
    "gemini-2.0-flash-lite",
    "gemini-1.5-flash",
    "gemini-1.5-flash-8b",
]

GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
GROK_BASE   = "https://api.x.ai/v1/chat/completions"
MISTRAL_BASE= "https://api.mistral.ai/v1/chat/completions"

# ── Track per-key failures this session ──────────────────────────────────────
_failed: set = set()   # "provider:key:model"


def _mark_failed(tag: str):
    _failed.add(tag)


def _ok(tag: str) -> bool:
    return tag not in _failed


# ── Gemini ────────────────────────────────────────────────────────────────────
async def _try_gemini(prompt: str, system: str, history: list, image_b64: str | None) -> str | None:
    cfg = get_config()
    keys = cfg.get("gemini_keys", [])
    if not keys:
        return None

    contents = _build_gemini_contents(history, prompt, image_b64)
    sys_inst = {"parts": [{"text": system}]} if system else None

    for model in GEMINI_MODELS:
        for key in keys:
            tag = f"gemini:{key[:8]}:{model}"
            if not _ok(tag):
                continue
            url = GEMINI_BASE.format(model=model) + f"?key={key}"
            body: dict = {"contents": contents}
            if sys_inst:
                body["systemInstruction"] = sys_inst
            body["generationConfig"] = {
                "maxOutputTokens": 800,
                "temperature": 0.7,
            }
            try:
                async with httpx.AsyncClient(timeout=30) as client:
                    r = await client.post(url, json=body)
                if r.status_code == 429 or r.status_code == 403:
                    logger.warning("Gemini rate limit: %s / %s", model, key[:8])
                    _mark_failed(tag)
                    continue
                r.raise_for_status()
                data = r.json()
                return data["candidates"][0]["content"]["parts"][0]["text"].strip()
            except Exception as e:
                logger.warning("Gemini error (%s): %s", tag, e)
                _mark_failed(tag)
                continue
    return None


def _build_gemini_contents(history: list, prompt: str, image_b64: str | None) -> list:
    contents = []
    for msg in history[-20:]:
        role = "user" if msg["role"] == "user" else "model"
        contents.append({"role": role, "parts": [{"text": msg["content"]}]})
    # current turn
    parts: list = []
    if image_b64:
        parts.append({"inlineData": {"mimeType": "image/jpeg", "data": image_b64}})
    parts.append({"text": prompt})
    contents.append({"role": "user", "parts": parts})
    return contents


# ── Grok ─────────────────────────────────────────────────────────────────────
async def _try_grok(prompt: str, system: str, history: list) -> str | None:
    cfg = get_config()
    keys = cfg.get("grok_keys", [])
    if not keys:
        return None

    messages = _build_openai_messages(system, history, prompt)
    for key in keys:
        tag = f"grok:{key[:8]}"
        if not _ok(tag):
            continue
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                r = await client.post(
                    GROK_BASE,
                    headers={"Authorization": f"Bearer {key}"},
                    json={"model": "grok-2-latest", "messages": messages, "max_tokens": 800},
                )
            if r.status_code == 429:
                _mark_failed(tag); continue
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"].strip()
        except Exception as e:
            logger.warning("Grok error: %s", e)
            _mark_failed(tag)
    return None


# ── Mistral ───────────────────────────────────────────────────────────────────
async def _try_mistral(prompt: str, system: str, history: list) -> str | None:
    cfg = get_config()
    keys = cfg.get("mistral_keys", [])
    if not keys:
        return None

    messages = _build_openai_messages(system, history, prompt)
    for key in keys:
        tag = f"mistral:{key[:8]}"
        if not _ok(tag):
            continue
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                r = await client.post(
                    MISTRAL_BASE,
                    headers={"Authorization": f"Bearer {key}"},
                    json={"model": "mistral-small-latest", "messages": messages, "max_tokens": 800},
                )
            if r.status_code == 429:
                _mark_failed(tag); continue
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"].strip()
        except Exception as e:
            logger.warning("Mistral error: %s", e)
            _mark_failed(tag)
    return None


def _build_openai_messages(system: str, history: list, prompt: str) -> list:
    msgs = []
    if system:
        msgs.append({"role": "system", "content": system})
    for m in history[-20:]:
        msgs.append({"role": m["role"], "content": m["content"]})
    msgs.append({"role": "user", "content": prompt})
    return msgs


# ── Public entry ──────────────────────────────────────────────────────────────
VOID_SYSTEM = (
    "You are VoidAI v2, an advanced AI assistant. "
    "Be concise, direct, and helpful. Never mention other AI names. "
    "Keep answers short unless deep explanation is needed. "
    "Do not pad responses."
)


async def ask_ai(
    prompt: str,
    history: list | None = None,
    image_b64: str | None = None,
    extra_context: str | None = None,
) -> str:
    history = history or []
    system = VOID_SYSTEM
    if extra_context:
        system += f"\n\nContext from web/image search:\n{extra_context}"

    result = await _try_gemini(prompt, system, history, image_b64)
    if result:
        return result

    result = await _try_grok(prompt, system, history)
    if result:
        return result

    result = await _try_mistral(prompt, system, history)
    if result:
        return result

    return "⚠️ All AI providers are currently unavailable. Please try again later."
