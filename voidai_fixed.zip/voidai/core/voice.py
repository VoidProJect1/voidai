"""
VoidAI v2 — Voice reply using Microsoft Edge TTS
"""

import asyncio, os, logging, tempfile
import edge_tts

logger = logging.getLogger(__name__)

# Indian voices supported by Edge TTS
INDIAN_VOICES = {
    "🇮🇳 Hindi - Swara (Female)":    "hi-IN-SwaraNeural",
    "🇮🇳 Hindi - Madhur (Male)":     "hi-IN-MadhurNeural",
    "🇮🇳 English - Neerja (Female)": "en-IN-NeerjaNeural",
    "🇮🇳 English - Prabhat (Male)":  "en-IN-PrabhatNeural",
    "🇮🇳 Telugu - Shruti (Female)":  "te-IN-ShrutiNeural",
    "🇮🇳 Telugu - Mohan (Male)":     "te-IN-MohanNeural",
    "🇮🇳 Tamil - Pallavi (Female)":  "ta-IN-PallaviNeural",
    "🇮🇳 Tamil - Valluvar (Male)":   "ta-IN-ValluvarNeural",
    "🇮🇳 Kannada - Sapna (Female)":  "kn-IN-SapnaNeural",
    "🇮🇳 Kannada - Gagan (Male)":    "kn-IN-GaganNeural",
}


async def text_to_speech(text: str, voice: str = "hi-IN-SwaraNeural") -> str | None:
    """Convert text to OGG audio file path."""
    try:
        tmp = tempfile.NamedTemporaryFile(suffix=".ogg", delete=False)
        tmp.close()
        communicate = edge_tts.Communicate(text, voice)
        await communicate.save(tmp.name)
        return tmp.name
    except Exception as e:
        logger.warning("TTS error: %s", e)
        return None


def clean_for_tts(text: str) -> str:
    """Remove markdown, emojis-heavy syntax for cleaner audio."""
    import re
    text = re.sub(r"\*+|_+|`+|#+", "", text)
    text = re.sub(r"\[([^\]]+)\]\([^\)]+\)", r"\1", text)
    text = text.strip()
    return text[:1000]   # cap length
