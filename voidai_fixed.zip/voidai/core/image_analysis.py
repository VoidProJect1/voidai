"""
VoidAI v2 — Image analysis
Downloads photo → base64 for Gemini vision.
For Pro mode: also does reverse image search via DuckDuckGo image search.
"""

import base64, httpx, logging
from io import BytesIO
from duckduckgo_search import DDGS

logger = logging.getLogger(__name__)


async def download_image_b64(file_url: str) -> str | None:
    """Download a Telegram file and return base64-encoded JPEG."""
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.get(file_url)
        r.raise_for_status()
        return base64.b64encode(r.content).decode()
    except Exception as e:
        logger.warning("Image download error: %s", e)
        return None


def reverse_image_search(image_url: str, max_results: int = 3) -> list[dict]:
    """Try DDG image search using keywords (DDG doesn't support true reverse search)."""
    # Fallback: search for the URL domain as context
    try:
        with DDGS() as ddgs:
            results = list(ddgs.images(f"image analysis {image_url[:60]}", max_results=max_results))
        return results
    except Exception as e:
        logger.warning("Reverse image search error: %s", e)
        return []


def summarise_image_search(results: list[dict]) -> str:
    if not results:
        return ""
    parts = []
    for r in results:
        parts.append(r.get("title", "") + " " + r.get("source", ""))
    return "Related web context: " + " | ".join(parts)[:400]
