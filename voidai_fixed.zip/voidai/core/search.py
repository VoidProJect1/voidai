"""
VoidAI v2 — Web search (DuckDuckGo, no API key needed)
"""

import logging
import time

logger = logging.getLogger(__name__)

MAX_RESULTS = 5


def web_search(query: str, max_results: int = MAX_RESULTS) -> list:
    """Return list of {title, href, body} dicts. Tries multiple fallback methods."""
    results = _try_ddgs_text(query, max_results)
    if results:
        return results

    # Short pause then retry once
    time.sleep(2)
    results = _try_ddgs_text(query, max_results)
    return results or []


def _try_ddgs_text(query: str, max_results: int) -> list:
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            results = list(ddgs.text(
                query,
                max_results=max_results,
                safesearch="moderate",
                timelimit=None,
            ))
        return results if results else []
    except Exception as e:
        logger.warning("DuckDuckGo search error: %s", e)
        return []


def format_search_results(results: list) -> str:
    """Plain summary for AI context (token-efficient)."""
    if not results:
        return "No results found."
    lines = []
    for i, r in enumerate(results, 1):
        title = r.get("title", "")
        body  = r.get("body", "")[:300]
        lines.append(f"{i}. {title}: {body}")
    return "\n".join(lines)


def format_search_for_user(query: str, results: list) -> str:
    """Pretty-printed result for /web command."""
    if not results:
        return (
            f"🔍 *No results found for:* `{query}`\n\n"
            "_DuckDuckGo returned no results. Try a shorter or different query._"
        )

    lines = [f"🌐 *Web Results for:* `{query}`\n"]
    for i, r in enumerate(results, 1):
        title = r.get("title", "Untitled")
        body  = r.get("body", "")[:250]
        url   = r.get("href", "")
        lines.append(
            f"{'🥇' if i == 1 else '🔹'} *{i}. {title}*\n"
            f"_{body}_\n"
            f"🔗 [Open link]({url})\n"
        )
    lines.append("—\n_Powered by VoidAI v2_ 🚀")
    return "\n".join(lines)
