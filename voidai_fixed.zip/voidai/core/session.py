"""
VoidAI v2 — Session manager
Stores per-user: model, voice settings, chat history (last 30 msgs)
"""

import time
from collections import defaultdict

# model choices
MODELS = {
    "lite":  "Void Lite",
    "flash": "Void Flash",
    "pro":   "Void Pro",
}

_sessions: dict[int, dict] = {}


def _default_session() -> dict:
    return {
        "model":        "flash",      # lite | flash | pro
        "history":      [],           # list of {role, content}
        "voice_on":     False,
        "voice_name":   "hi-IN-SwaraNeural",
        "created_at":   time.time(),
    }


def get_session(user_id: int) -> dict:
    if user_id not in _sessions:
        _sessions[user_id] = _default_session()
    return _sessions[user_id]


def reset_session(user_id: int):
    _sessions[user_id] = _default_session()


def add_to_history(user_id: int, role: str, content: str):
    sess = get_session(user_id)
    sess["history"].append({"role": role, "content": content})
    # Keep last 30 messages
    if len(sess["history"]) > 30:
        sess["history"] = sess["history"][-30:]


def get_history(user_id: int) -> list:
    return get_session(user_id)["history"]


def set_model(user_id: int, model: str):
    if model in MODELS:
        get_session(user_id)["model"] = model


def get_model(user_id: int) -> str:
    return get_session(user_id)["model"]


def set_voice(user_id: int, on: bool, voice_name: str | None = None):
    sess = get_session(user_id)
    sess["voice_on"] = on
    if voice_name:
        sess["voice_name"] = voice_name


def get_voice(user_id: int) -> tuple[bool, str]:
    sess = get_session(user_id)
    return sess["voice_on"], sess["voice_name"]
