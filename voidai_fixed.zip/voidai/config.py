"""
VoidAI v2 — Config & persistent settings (JSON-backed)
"""

import json, os

CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "void_config.json")

# ── Bot token ─────────────────────────────────────────────────────────────────
BOT_TOKEN = "8613601784:AAGPQbhIYwJqc30g99X3yLa6Vhkkl69Nf8I"

# ── Hardcoded bootstrap admin (always has access) ────────────────────────────
BOOTSTRAP_ADMIN_ID = 5479881365

# ── Default config structure ──────────────────────────────────────────────────
_DEFAULTS = {
    "admin_ids": [BOOTSTRAP_ADMIN_ID],

    # API keys — lists allow round-robin rotation
    "gemini_keys": [],
    "grok_keys":   [],
    "mistral_keys":[],

    # Global usage limits (per hour)
    "limits": {
        "lite":  {"messages": 200, "images": 5,  "searches": 30},
        "flash": {"messages": 80,  "images": 5,  "searches": 30},
        "pro":   {"messages": 40,  "images": 5,  "searches": 30},
    },

    # Per-user overrides  {user_id: multiplier}
    "user_limit_multipliers": {},

    # Banned users  [user_id, ...]
    "banned_users": [],

    # Group-level limit multiplier  {chat_id: multiplier}
    "group_multipliers": {},
}


def _load() -> dict:
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                data = json.load(f)
            # merge missing keys
            for k, v in _DEFAULTS.items():
                if k not in data:
                    data[k] = v
            # ensure bootstrap admin always present
            if BOOTSTRAP_ADMIN_ID not in data["admin_ids"]:
                data["admin_ids"].append(BOOTSTRAP_ADMIN_ID)
            return data
        except Exception:
            pass
    cfg = dict(_DEFAULTS)
    _save(cfg)
    return cfg


def _save(cfg: dict):
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)


def get_config() -> dict:
    return _load()


def save_config(cfg: dict):
    _save(cfg)


def get_admin_ids():
    ids = _load()["admin_ids"]
    if BOOTSTRAP_ADMIN_ID not in ids:
        ids.append(BOOTSTRAP_ADMIN_ID)
    return ids


def is_admin(user_id: int) -> bool:
    return user_id == BOOTSTRAP_ADMIN_ID or user_id in get_admin_ids()


def is_banned(user_id: int) -> bool:
    return user_id in _load()["banned_users"]
