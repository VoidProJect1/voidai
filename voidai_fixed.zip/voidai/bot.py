"""
VoidAI v2 — Entry point
"""

import asyncio
import logging
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler,
    CallbackQueryHandler, filters
)

from config import BOT_TOKEN
from handlers.commands import (
    start_handler, help_handler, new_handler,
    switch_handler, summarize_handler, web_handler,
    voicereply_handler
)
from handlers.messages import message_handler
from handlers.admin import (
    admin_handler, ban_handler, limit_handler,
    stats_handler, addkey_handler, addadmin_handler
)
from handlers.callbacks import callback_handler

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)


def main():
    if not BOT_TOKEN:
        logger.error("BOT_TOKEN not set.")
        return

    app = ApplicationBuilder().token(BOT_TOKEN).build()

    # User commands
    app.add_handler(CommandHandler("start",      start_handler))
    app.add_handler(CommandHandler("help",       help_handler))
    app.add_handler(CommandHandler("new",        new_handler))
    app.add_handler(CommandHandler("switch",     switch_handler))
    app.add_handler(CommandHandler("summarize",  summarize_handler))
    app.add_handler(CommandHandler("web",        web_handler))
    app.add_handler(CommandHandler("voicereply", voicereply_handler))

    # Admin commands
    app.add_handler(CommandHandler("admin",    admin_handler))
    app.add_handler(CommandHandler("ban",      ban_handler))
    app.add_handler(CommandHandler("limit",    limit_handler))
    app.add_handler(CommandHandler("stats",    stats_handler))
    app.add_handler(CommandHandler("addkey",   addkey_handler))
    app.add_handler(CommandHandler("addadmin", addadmin_handler))

    # Inline buttons
    app.add_handler(CallbackQueryHandler(callback_handler))

    # Messages
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND, message_handler
    ))
    app.add_handler(MessageHandler(filters.PHOTO, message_handler))

    logger.info("VoidAI v2 is running...")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
